from django import forms
from .models import Flight, Booking

class FlightForm(forms.ModelForm):
    class Meta:
        model = Flight
        fields = ['flight_number', 'departure_city', 'arrival_city', 'departure_time', 'arrival_time', 'seats_available']

class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['flight', 'passenger_name', 'seat_count']
