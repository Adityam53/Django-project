from django.db import models

# Create your models here.

class Flight(models.Model):
    flight_number = models.CharField(max_length=10, unique=True)
    departure_city = models.CharField(max_length=100)
    arrival_city = models.CharField(max_length=100)
    departure_time = models.DateTimeField()
    arrival_time = models.DateTimeField()
    seats_available = models.IntegerField()

    def __str__(self):
        return f"{self.flight_number} ({self.departure_city} to {self.arrival_city})"

class Booking(models.Model):
    flight = models.ForeignKey(Flight, related_name="bookings", on_delete=models.CASCADE)
    passenger_name = models.CharField(max_length=100)
    seat_count = models.IntegerField()

    def __str__(self):
        return f"Booking by {self.passenger_name} for {self.flight}"