from django.shortcuts import render, get_object_or_404, redirect
from .models import Flight, Booking
from .forms import FlightForm, BookingForm
from django.contrib import messages  # For success/error messages


# List all flights
def flight_list(request):
    flights = Flight.objects.all()
    return render(request, 'flights/flight_list.html', {'flights': flights})

# View flight details
def flight_detail(request, pk):
    flight = get_object_or_404(Flight, pk=pk)
    return render(request, 'flights/flight_detail.html', {'flight': flight})

# Create a new flight
def flight_create(request):
    if request.method == 'POST':
        form = FlightForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('flight_list')
    else:
        form = FlightForm()
    return render(request, 'flights/flight_form.html', {'form': form})

# Update flight details
def flight_update(request, pk):
    flight = get_object_or_404(Flight, pk=pk)
    if request.method == 'POST':
        form = FlightForm(request.POST, instance=flight)
        if form.is_valid():
            form.save()
            return redirect('flight_detail', pk=flight.pk)
    else:
        form = FlightForm(instance=flight)
    return render(request, 'flights/flight_form.html', {'form': form})

# Delete a flight
def flight_delete(request, pk):
    flight = get_object_or_404(Flight, pk=pk)
    flight.delete()
    return redirect('flight_list')

# Book a flight
def booking_create(request, flight_id):
    # Retrieve the flight by its ID, or return a 404 if not found
    flight = get_object_or_404(Flight, pk=flight_id)

    if request.method == 'POST':
        # Instantiate the booking form with the POST data
        form = BookingForm(request.POST)
        if form.is_valid():
            # Check if there are enough seats available
            seat_count = form.cleaned_data['seat_count']
            if seat_count > flight.seats_available:
                # If not enough seats, show an error message
                messages.error(request, f"Not enough seats available! Only {flight.seats_available} seats left.")
                return redirect('flight_detail', pk=flight.pk)

            # Create a booking object but don't save it yet
            booking = form.save(commit=False)
            # Link the booking to the flight
            booking.flight = flight
            # Save the booking to the database
            booking.save()

            # Update the number of seats available for the flight
            flight.seats_available -= seat_count
            flight.save()

            # Redirect to the flight detail page after successful booking
            messages.success(request, f"Successfully booked {seat_count} seats for flight {flight.flight_number}.")
            return redirect('flight_detail', pk=flight.pk)
    else:
        # Create an empty form if the request is GET
        form = BookingForm()

    # Render the booking form in the template
    return render(request, 'flights/booking_form.html', {'form': form, 'flight': flight})